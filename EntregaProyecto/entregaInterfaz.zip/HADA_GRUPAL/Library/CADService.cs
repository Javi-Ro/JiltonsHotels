﻿using System;
using System.Collections.Generic;

namespace Library
{
    public class CADService
    {
        private string constring;

        public CADService()
        {

        }

        public bool createService(ENService en)
        {
 
        }

        public bool deleteService(ENService en)
        {

        }

        public bool updateService(ENService en)
        {

        }

        public List<ENService> listAllServices()
        {

        }

        public ENService searchService()
        {

        }

    }
}