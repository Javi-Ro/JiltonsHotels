﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Data.SqlTypes;

namespace Library
{
    public class CADCar
    {

        private string constring;

        public CADCar()
        {

        }

        public bool createCar(ENCar en)
        {
        
        }

        public bool deleteCar(ENCar en)
        {

        }

        public bool updatePriceCar(ENCar en)
        {

        }
        public List<ENCar> listAllCars()
        {

        }


    }
}
