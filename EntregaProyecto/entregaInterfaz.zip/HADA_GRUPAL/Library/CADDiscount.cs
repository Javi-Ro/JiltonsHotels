﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library
{
    class CADDiscount
    {
        string constring;

        public CADDiscount()
        {

        }

        public bool createDiscount(ENDiscount discount)
        {

        }

        public bool deleteDiscount(ENDiscount discount)
        {

        }

        public bool updatePercentage(ENDiscount discount)
        {

        }

        public ENBooking[] getBookings(ENDiscount discount)
        {

        }


    }
}