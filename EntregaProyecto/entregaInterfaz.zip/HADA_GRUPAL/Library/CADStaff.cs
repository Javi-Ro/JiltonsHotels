﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Data.SqlTypes;

namespace Library
{
    public class CADStaff
    {

        private string constring;

        public CADStaff()
        {

        }

        public bool createStaff(ENStaff en)
        {

        }

        public bool deleteStaff(ENStaff en)
        {

        }

        public bool updateContactStaff(ENStaff en)
        {

        }

        public bool updateTelephoneStaff(ENStaff en)
        {

        }
        public bool updateWageStaff(ENStaff en)
        {

        }

    }
}
