﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Configuration;

namespace Library
{
    public class CADBooking
    {
        private string constring;

        public CADBooking()
        {

        }

        // Methods for bookings (CRUD operations)
        public bool createBooking(ENBooking booking)
        {

        }

        public bool deleteBooking(ENBooking booking)
        {

        }

        public List<ENBooking> listAllBookings()
        {

        }

        public ENBooking searchBooking(ENUser user, IntervalDate interval)
        {

        }

        public bool updateBooking(ENBooking booking)
        {

        }

        // Methods for rooms
        public List<ENRoom> getRooms(ENBooking booking)
        {

        }

        public bool addRoom(ENBooking booking, ENRoom room)
        {

        }

        public bool deleteRoom(ENBooking booking, ENRoom room)
        {

        }

        // Methods for services
        public List<ENService> getServices(ENBooking booking)
        {

        }

        public bool addService(ENBooking booking, ENService service)
        {

        }

        public bool cancelService(ENBooking booking, ENService service)
        {

        }

        // Methods for packages
        public bool addPackage(ENBooking booking, ENPackage package)
        {

        }

        public bool cancelPackage(ENBooking booking, ENPackage package)
        {

        }

        public List<ENPackage> getPackages(ENBooking booking)
        {
               
        }

        // Methods for discounts
        public bool applyDiscount(ENBooking booking, ENDiscount discount)
        {

        }

        public bool quitDiscount(ENBooking booking, ENDiscount discount)
        {

        }

        // Car leasing
        public bool addCar(ENBooking booking, ENCar car)
        {

        }

        public bool deleteCar(ENBooking booking, ENCar car)
        {

        }

        public List<ENCar> getCars(ENBooking booking)
        {

        }
    }
}
